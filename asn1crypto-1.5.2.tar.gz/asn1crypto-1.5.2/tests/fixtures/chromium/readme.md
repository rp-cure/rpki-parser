Various certificates from
https://chromium.googlesource.com/chromium/src.git/+/master/net/data/ssl/certificates/.
