Example EV certificate and chain.
