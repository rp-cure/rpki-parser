Valid and invalid certificates using name constraints. From
https://cabforum.org/pipermail/public/2013-July/001839.html.
