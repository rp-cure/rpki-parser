# Fixtures

Item of note: the files `cms-signed-digested.pem`, `cms-signed-digested.der`,
`pkcs7-signed-digested.pem` and `pkcs7-signed-digested.der` all have invalid
signatures since the structures were hand edited to highlight the one
incompatibility between CMS and PKCS#7.
