# asn1crypto_tests

Run the test suite via:

```bash
python -m asn1crypto_tests
```

Full documentation a <https://github.com/wbond/asn1crypto#readme>.
